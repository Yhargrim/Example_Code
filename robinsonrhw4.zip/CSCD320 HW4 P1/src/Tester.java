//Ron Robinson. Justin Ching
//Homework 4 Part 1

import java.util.LinkedList;

public class Tester {
	
	public static void main(String[] args) {
		Trie2 myTrie = new Trie2();
		
		myTrie.insertString("apple");
		myTrie.insertString("bike");
		myTrie.insertString("bake");
		myTrie.insertString("pen");
		myTrie.insertString("did");
		myTrie.insertString("ape");
		myTrie.insertString("child");
		myTrie.insertString("cat");
		myTrie.insertString("file");
		myTrie.insertString("hello");
		myTrie.insertString("he");
		myTrie.insertString("hell");
		
		LinkedList<String> nl = myTrie.wordsPrefixedBy("ap");
		System.out.println(nl.toString());
		
		nl = myTrie.wordsPrefixedBy("he");
		System.out.println(nl.toString());
	}

}
