import java.util.Map;
import java.util.TreeMap;

public class DictPrefixTree implements Dictionary {

	private TrieNode root;
	
	private class TrieNode {
		Map<Character, TrieNode> children = new TreeMap<>();
		boolean aword = false;
	}
	
	public DictPrefixTree() {
		this.root = new TrieNode();
	}
	
	public boolean isWord(String str) {
		if (str == null || str.isEmpty())
			return false;
		TrieNode cur = this.root;
		while (str.length() > 0 && cur != null) {
			char ch = str.charAt(0);
			str = str.substring(1);
			cur = cur.children.get(ch);
		}
		if (cur != null)
			return cur.aword;
		return false;
	}

	public void insert(String s) {
		insert(root, s);
	}
	
	private void insert(TrieNode root, String s) {
		TrieNode cur = root;
		for (char ch : s.toCharArray()) {
			TrieNode next = cur.children.get(ch);
			if (next == null)
				cur.children.put(ch, next = new TrieNode());
			cur = next;
		}
		cur.aword = true;
	}
}
