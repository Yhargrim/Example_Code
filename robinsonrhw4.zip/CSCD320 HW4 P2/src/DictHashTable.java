import java.util.Hashtable;

public class DictHashTable implements Dictionary {
	
	private Hashtable<String, Integer> hash;
	
	public DictHashTable() {
		hash = new Hashtable<String, Integer>();
	}
	
	public void insert(String s) {
		hash.put(s, 1);
	}
	
	public boolean isWord(String str) {
		boolean result = false;
		if (hash.get(str) != null)
			result = true;
		return result;
	}
	
}
