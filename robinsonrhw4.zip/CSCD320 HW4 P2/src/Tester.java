//Ron Robinson. Justin Ching
//Homework 4 Part 2
import java.io.File;
import java.util.Scanner;

public class Tester {
	
	public static void main(String[] args) throws Exception {
		
		SolverTree solve = new SolverTree();
		File file = new File("dictionary.txt");
		Scanner scan = new Scanner(file);
		DictHashTable hashDict = new DictHashTable();
		DictPrefixTree prefDict = new DictPrefixTree();
		String holder;
		String[] splitter;
		
		while (scan.hasNext()) {
			holder = scan.nextLine();
			splitter = holder.split(",");
			hashDict.insert(splitter[0]);
		}
		
		scan = new Scanner(file);
		while (scan.hasNext()) {
			holder = scan.nextLine();
			splitter = holder.split(",");
			prefDict.insert(splitter[0]);
		}
		scan = new Scanner(System.in);
		String digits = "";
		
		System.out.println("2: ABC");
		System.out.println("3: DEF");
		System.out.println("4: GHI");
		System.out.println("5: JKL");
		System.out.println("6: MNO");
		System.out.println("7: PQRS");
		System.out.println("8: TUV");
		System.out.println("9: WXYZ");
		
		while (digits.compareTo("exit") != 0) {
		printMenu();
		digits = scan.nextLine();
		System.out.println();
		if (digits.compareTo("exit") == 0) {
			System.out.println("Exiting...");
			return;
		}
		digits = digits.replaceAll("[^2-9]", "");
		System.out.println("Searching: " + digits);
		System.out.println("Using Hash Dictionary: ");
		solve.searchSolver(solve.root, digits, hashDict);
		System.out.println();
		System.out.println("Using Prefix Tree Dictionary: ");
		solve.searchSolver(solve.root, digits, prefDict);
		System.out.println();
		}
		
	}
	
	private static void printMenu() {
		System.out.println();
		System.out.println("Enter exit or digits to search: ");
	}

}
