
public abstract interface Dictionary {
	
	public abstract boolean isWord(String str);

}
