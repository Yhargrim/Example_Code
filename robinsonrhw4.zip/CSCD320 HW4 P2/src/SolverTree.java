import java.util.Arrays;
import java.util.Hashtable;

public class SolverTree {
	
	Node root;
	
	private class Node {
		Character data;
		Node c1, c2, c3, c4;
	}
	
	public SolverTree() {
		root = new Node();
	}
	
	public void searchSolver(Node root, String str, Dictionary D) {
		if (root == null || str == null || str.isEmpty())
			return;
		
		int[] digits = new int[str.length()];
		for (int ix = 0; ix < str.length(); ix++)
			digits[ix] = Character.getNumericValue(str.charAt(ix));
		
		root = buildSolver(digits, root, buildPhone());
		
		checkPaths(root, "", D, str.length());
	}
	
	private void checkPaths(Node root, String str, Dictionary D, int lengthCheck) {
		if (root == null)
			return;
		if (root.data != null)
			str += root.data;
		if (str.length() == lengthCheck && noChild(root) && D.isWord(str))
			System.out.print(str + " ");
		else {
			checkPaths(root.c1, str, D, lengthCheck);
			checkPaths(root.c2, str, D, lengthCheck);
			checkPaths(root.c3, str, D, lengthCheck);
			checkPaths(root.c4, str, D, lengthCheck);
		}
	}
	
	private Node buildSolver(int[] digits, Node root, Hashtable<Integer, String> phone) {
		if (digits == null || digits.length == 0)
			return root;
		
		root.c1 = new Node();
		root.c2 = new Node();
		root.c3 = new Node();
		root.c4 = new Node();
		
		root.c1.data = convertDigit(digits[0], 1, phone);
		root.c2.data = convertDigit(digits[0], 2, phone);
		root.c3.data = convertDigit(digits[0], 3, phone);
		root.c4.data = convertDigit(digits[0], 4, phone);
		
		root.c1 = buildSolver(Arrays.copyOfRange(digits, 1, digits.length), root.c1, phone);
		root.c2 = buildSolver(Arrays.copyOfRange(digits, 1, digits.length), root.c2, phone);
		root.c3 = buildSolver(Arrays.copyOfRange(digits, 1, digits.length), root.c3, phone);
		root.c4 = buildSolver(Arrays.copyOfRange(digits, 1, digits.length), root.c4, phone);
		
		return root;
	}
	
	private Hashtable<Integer, String> buildPhone() {
		Hashtable<Integer, String> phone = new Hashtable<Integer, String>();
		phone.put(2, "abc");
		phone.put(3, "def");
		phone.put(4, "ghi");
		phone.put(5, "jkl");
		phone.put(6, "mno");
		phone.put(7, "pqrs");
		phone.put(8, "tuv");
		phone.put(9, "wxyz");
		return phone;
	}
	
	private Character convertDigit(int digit, int num, Hashtable<Integer, String> phone) {
		String str = phone.get(digit);
		if (num-1 < str.length()) {
			char ch = str.charAt(num-1);
			return ch;
		}
		return null;
	}
	
	private boolean noChild(Node root) {
		if (root == null)
			return true;
		if (root.c1 == null &&
			root.c2 == null &&
			root.c3 == null &&
			root.c4 == null)
			return true;
		else
			return false;
	}

}
